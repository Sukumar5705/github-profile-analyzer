import profileRepo from '../repositories/profile.repository.js';
import skillRepo from '../repositories/skill.repository.js';
import analysisRepo from '../repositories/analysis.repository.js';
import logger from '../utils/logger.js';

/**
 * POST /api/analysis/:username/generate-ai
 * Returns unified AI report (summary, roadmap, portfolio review) for a stored profile.
 * Reads the pre-computed, persisted LLM analysis to ensure instant response times
 * without issuing duplicate external LLM requests.
 */
const generateAI = async (req, res, next) => {
  try {
    const { username } = req.params;
    logger.info(`[AI Controller] Retrieving AI report for ${username}`);

    const profile = await profileRepo.findByUsername(username);
    if (!profile) {
      return res.status(404).json({
        success: false,
        message: 'Profile not found. Run POST /api/github/analyze/:username first.'
      });
    }

    const [skills, analysis] = await Promise.all([
      skillRepo.findByProfileId(profile.id),
      analysisRepo.findByProfileId(profile.id)
    ]);

    if (!analysis) {
      return res.status(400).json({
        success: false,
        message: 'No analysis found for this profile. Run POST /api/github/analyze/:username first.'
      });
    }

    const strengths = safeParseJSON(analysis.strengths, []);
    const concerns = safeParseJSON(analysis.concerns, []);
    const gaps = safeParseJSON(analysis.gaps, []);
    const learningRoadmap = safeParseJSON(analysis.learning_roadmap, null);

    // Build structured aiSummary
    const improvements = gaps.map(g => (typeof g === 'object' ? (g.advice || g.area) : String(g)));
    const aiSummary = {
      summary: analysis.executive_summary || `Analysis completed for ${profile.username}.`,
      strengths: strengths.length ? strengths : ['Demonstrated coding commitment across repositories'],
      improvements: improvements.length ? improvements : ['Continue enhancing test coverage and CI/CD automation']
    };

    // Build structured roadmap
    const roadmap = (learningRoadmap && learningRoadmap.month1)
      ? {
          roadmap: {
            month1: learningRoadmap.month1,
            month2: learningRoadmap.month2,
            month3: learningRoadmap.month3
          },
          goal: learningRoadmap.goal || 'Reach advanced full-stack & production-readiness level.'
        }
      : {
          roadmap: {
            month1: { focus: 'Testing & Core Code Quality', tasks: ['Add automated tests', 'Improve README docs'] },
            month2: { focus: 'Containerization & CI/CD', tasks: ['Dockerize key services', 'Setup GitHub Actions'] },
            month3: { focus: 'Production Architecture & Cloud', tasks: ['Deploy live service', 'Add observability'] }
          },
          goal: 'Master production-grade application deployment.'
        };

    // Build structured portfolioReview
    const portfolioReview = {
      verdict: analysis.hiring_recommendation || `${analysis.developer_type || 'Full Stack'} Developer`,
      strengths: strengths.slice(0, 3),
      weaknesses: concerns.slice(0, 3),
      recruiterImpression: analysis.recruiter_summary || analysis.executive_summary || 'Solid candidate with demonstrable technical skills.'
    };

    res.status(200).json({
      success: true,
      message: 'AI report generated successfully',
      data: {
        username: profile.username,
        aiSummary,
        roadmap,
        portfolioReview,
        resumeEvidence: safeParseJSON(analysis.resume_evidence, {}),
        portfolioShowcase: safeParseJSON(analysis.portfolio_showcase, null)
      }
    });
  } catch (err) {
    next(err);
  }
};

function safeParseJSON(val, fallback) {
  if (!val) return fallback;
  if (typeof val === 'object') return val;
  try {
    return JSON.parse(val);
  } catch {
    return fallback;
  }
}

export { generateAI };
export default { generateAI };
