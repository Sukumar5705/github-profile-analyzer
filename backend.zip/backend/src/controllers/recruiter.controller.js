import profileRepo   from '../repositories/profile.repository.js';
import skillRepo     from '../repositories/skill.repository.js';
import analysisRepo  from '../repositories/analysis.repository.js';
import repositoryRepo from '../repositories/repository.repository.js';
import { analyzeProfile } from '../services/analysis.service.js';
import logger        from '../utils/logger.js';

/**
 * GET /api/recruiter/:username
 * Returns a recruiter-friendly snapshot of a developer.
 * Auto-triggers analysis if the profile hasn't been analyzed yet.
 */
const getRecruiterView = async (req, res, next) => {
  try {
    const { username } = req.params;
    logger.info(`[recruiterView] ${username}`);

    let profile = await profileRepo.findByUsername(username);

    // Auto-analyze if not yet in DB
    if (!profile) {
      const result = await analyzeProfile(username);
      return res.status(200).json({
        success: true,
        message: 'Profile analyzed and recruiter view generated',
        data: buildRecruiterResponse(result)
      });
    }

    const [skills, analysis, repos] = await Promise.all([
      skillRepo.findByProfileId(profile.id),
      analysisRepo.findByProfileId(profile.id),
      repositoryRepo.findByProfileId(profile.id)
    ]);

    if (!analysis) {
      const result = await analyzeProfile(username);
      return res.status(200).json({
        success: true,
        data: buildRecruiterResponse(result)
      });
    }

    // Parse JSON columns from DB
    const topProjects   = safeParseJSON(analysis.top_projects, []);
    const strengths     = safeParseJSON(analysis.strengths, []);
    const concerns      = safeParseJSON(analysis.concerns, []);
    const gaps          = safeParseJSON(analysis.gaps, []);
    const recommendations = safeParseJSON(analysis.recommendations, []);
    const devReasons    = safeParseJSON(analysis.developer_reasons, []);

    res.status(200).json({
      success: true,
      data: {
        profile: {
          username:    profile.username,
          name:        profile.name,
          bio:         profile.bio,
          followers:   profile.followers,
          public_repos: profile.public_repos,
          avatar_url:  profile.avatar_url,
          profile_url: profile.profile_url
        },
        developerType: {
          type:       analysis.developer_type,
          confidence: analysis.developer_confidence,
          reasons:    devReasons
        },
        careerScore: {
          score: analysis.career_score,
          breakdown: {
            documentation: analysis.score_documentation,
            diversity:     analysis.score_diversity,
            deployment:    analysis.score_deployment,
            techBreadth:   analysis.score_tech_breadth,
            activity:      analysis.score_activity,
            openSource:    analysis.score_open_source
          }
        },
        skills:          skills.slice(0, 10),
        topProjects:     topProjects.slice(0, 5),
        strengths,
        concerns,
        gaps,
        recommendations: recommendations.slice(0, 5),
        summary: {
          totalStars:    analysis.total_stars,
          totalForks:    analysis.total_forks,
          mostUsedLanguage: analysis.most_used_language
        },
        analyzedAt: analysis.analyzed_at
      }
    });
  } catch (err) { next(err); }
};

/**
 * GET /api/recruiter/:username/history
 * Returns career score history for trend visualization.
 */
const getScoreHistory = async (req, res, next) => {
  try {
    const { username } = req.params;
    const profile = await profileRepo.findByUsername(username);
    if (!profile) return res.status(404).json({ success: false, message: 'Profile not found' });

    const history = await analysisRepo.getHistory(profile.id, 30);
    res.status(200).json({ success: true, data: history });
  } catch (err) { next(err); }
};

// ── Helpers ────────────────────────────────────────────────────

function buildRecruiterResponse(result) {
  return {
    profile: {
      username:    result.profile.username,
      name:        result.profile.name,
      bio:         result.profile.bio,
      followers:   result.profile.followers,
      public_repos: result.profile.public_repos,
      avatar_url:  result.profile.avatar_url,
      profile_url: result.profile.profile_url
    },
    developerType:   result.developerType,
    careerScore:     result.careerScore,
    skills:          result.skills.slice(0, 10),
    topProjects:     result.topProjects.slice(0, 5),
    strengths:       result.recruiter.strengths,
    concerns:        result.recruiter.concerns,
    gaps:            result.gaps,
    recommendations: result.recommendations.slice(0, 5),
    summary:         result.summary
  };
}

function safeParseJSON(val, fallback) {
  if (!val) return fallback;
  if (typeof val === 'object') return val; // already parsed by mysql2
  try { return JSON.parse(val); } catch { return fallback; }
}

export { getRecruiterView, getScoreHistory };
