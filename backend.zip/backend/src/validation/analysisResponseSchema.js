/**
 * analysisResponseSchema.js
 *
 * Declarative contract defining the shape, required keys,
 * value bounds, and enum constraints for the single LLM analysis response.
 * Includes the native Gemini OpenAPI JSON Schema for structured output generation.
 */

export const REQUIRED_TOP_LEVEL_KEYS = [
  'developerType',
  'careerScore',
  'executiveSummary',
  'strengths',
  'weaknesses',
  'hiringRecommendation',
  'recruiterSummary',
  'portfolioGaps',
  'recommendations',
  'learningRoadmap'
];

export const VALID_SEVERITIES = new Set(['high', 'medium', 'low']);
export const VALID_PRIORITIES = new Set(['high', 'medium', 'low']);

export const SHOWCASE_KEYS = [
  'resumeProject',
  'technicalProject',
  'recruiterProject',
  'architectureProject'
];

export const ROADMAP_MONTHS = ['month1', 'month2', 'month3'];

export const GEMINI_RESPONSE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    developerType: {
      type: 'OBJECT',
      properties: {
        developerType: { type: 'STRING' },
        confidence: { type: 'NUMBER' },
        reasons: { type: 'ARRAY', items: { type: 'STRING' } }
      },
      required: ['developerType', 'confidence', 'reasons']
    },
    careerScore: {
      type: 'OBJECT',
      properties: {
        score: { type: 'INTEGER' },
        breakdown: {
          type: 'OBJECT',
          properties: {
            documentation: { type: 'INTEGER' },
            diversity: { type: 'INTEGER' },
            deployment: { type: 'INTEGER' },
            techBreadth: { type: 'INTEGER' },
            activity: { type: 'INTEGER' },
            openSource: { type: 'INTEGER' }
          },
          required: ['documentation', 'diversity', 'deployment', 'techBreadth', 'activity', 'openSource']
        },
        label: { type: 'STRING' }
      },
      required: ['score', 'breakdown', 'label']
    },
    executiveSummary: { type: 'STRING' },
    strengths: { type: 'ARRAY', items: { type: 'STRING' } },
    weaknesses: { type: 'ARRAY', items: { type: 'STRING' } },
    hiringRecommendation: { type: 'STRING' },
    recruiterSummary: { type: 'STRING' },
    portfolioGaps: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          area: { type: 'STRING' },
          severity: { type: 'STRING' },
          advice: { type: 'STRING' }
        },
        required: ['area', 'severity', 'advice']
      }
    },
    recommendations: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          priority: { type: 'STRING' },
          recommendation: { type: 'STRING' }
        },
        required: ['priority', 'recommendation']
      }
    },
    learningRoadmap: {
      type: 'OBJECT',
      properties: {
        month1: {
          type: 'OBJECT',
          properties: { focus: { type: 'STRING' }, tasks: { type: 'ARRAY', items: { type: 'STRING' } } },
          required: ['focus', 'tasks']
        },
        month2: {
          type: 'OBJECT',
          properties: { focus: { type: 'STRING' }, tasks: { type: 'ARRAY', items: { type: 'STRING' } } },
          required: ['focus', 'tasks']
        },
        month3: {
          type: 'OBJECT',
          properties: { focus: { type: 'STRING' }, tasks: { type: 'ARRAY', items: { type: 'STRING' } } },
          required: ['focus', 'tasks']
        },
        goal: { type: 'STRING' }
      },
      required: ['month1', 'month2', 'month3', 'goal']
    }
  },
  required: REQUIRED_TOP_LEVEL_KEYS
};

export default {
  REQUIRED_TOP_LEVEL_KEYS,
  VALID_SEVERITIES,
  VALID_PRIORITIES,
  SHOWCASE_KEYS,
  ROADMAP_MONTHS,
  GEMINI_RESPONSE_SCHEMA
};
