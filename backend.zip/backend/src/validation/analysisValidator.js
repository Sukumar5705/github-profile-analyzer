/**
 * analysisValidator.js
 *
 * Stage: JSON Validator
 * Validates, cleanses, bounds-checks, and sanitizes the parsed LLM analysis response.
 * Merges deterministic facts from evidenceBuilder for projects, showcase, and resume evidence.
 */

import {
  REQUIRED_TOP_LEVEL_KEYS,
  VALID_SEVERITIES,
  VALID_PRIORITIES,
  SHOWCASE_KEYS,
  ROADMAP_MONTHS
} from './analysisResponseSchema.js';
import {
  getDeterministicTopProjects,
  getDeterministicShowcase,
  getDeterministicResumeEvidence
} from '../evidence/projectFactSheet.js';
import logger from '../utils/logger.js';

export class AnalysisValidationError extends Error {
  constructor(message, details = []) {
    super(message);
    this.name = 'AnalysisValidationError';
    this.details = details;
  }
}

/**
 * Clamps a number between min and max.
 */
function clamp(val, min, max, defaultVal = min) {
  const num = Number(val);
  if (!Number.isFinite(num)) return defaultVal;
  return Math.min(max, Math.max(min, num));
}

/**
 * Validates and sanitizes the parsed analysis JSON from the LLM.
 * @param {object} raw - Parsed JSON object
 * @param {object} [fallbackEvidence] - Optional DeveloperEvidence for deterministic fallbacks
 * @returns {object} Validated, sanitized analysis object
 */
export function validateAndSanitizeAnalysis(raw, fallbackEvidence = null) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    throw new AnalysisValidationError('LLM output is not a valid JSON object');
  }

  const errors = [];
  for (const key of REQUIRED_TOP_LEVEL_KEYS) {
    if (raw[key] === undefined || raw[key] === null) {
      errors.push(`Missing top-level property: ${key}`);
    }
  }

  if (errors.length > 5) {
    throw new AnalysisValidationError('LLM output deviates significantly from schema', errors);
  }

  // 1. developerType
  const devTypeObj = raw.developerType || {};
  const developerType = {
    developerType: typeof devTypeObj.developerType === 'string' && devTypeObj.developerType.trim()
      ? devTypeObj.developerType.trim()
      : 'Software Engineer',
    confidence: clamp(devTypeObj.confidence, 0.0, 1.0, 0.9),
    reasons: Array.isArray(devTypeObj.reasons)
      ? devTypeObj.reasons.map(r => String(r).trim()).filter(Boolean).slice(0, 3)
      : []
  };

  // 2. careerScore
  const csObj = raw.careerScore || {};
  const breakdownObj = csObj.breakdown || {};
  const documentation = clamp(breakdownObj.documentation, 0, 20, 12);
  const diversity = clamp(breakdownObj.diversity, 0, 20, 12);
  const deployment = clamp(breakdownObj.deployment, 0, 20, 12);
  const techBreadth = clamp(breakdownObj.techBreadth, 0, 15, 10);
  const activity = clamp(breakdownObj.activity, 0, 15, 10);
  const openSource = clamp(breakdownObj.openSource, 0, 10, 6);

  const rawScore = Number(csObj.score);
  const computedTotal = documentation + diversity + deployment + techBreadth + activity + openSource;
  const score = clamp(Number.isFinite(rawScore) ? rawScore : computedTotal, 0, 100, computedTotal);

  let scoreLabel = typeof csObj.label === 'string' && csObj.label.trim() ? csObj.label.trim() : null;
  if (!scoreLabel) {
    if (score >= 85) scoreLabel = 'Exceptional';
    else if (score >= 70) scoreLabel = 'Strong';
    else if (score >= 55) scoreLabel = 'Competent';
    else if (score >= 40) scoreLabel = 'Developing';
    else scoreLabel = 'Beginner';
  }

  const careerScore = {
    score: Math.round(score),
    breakdown: {
      documentation: Math.round(documentation),
      diversity: Math.round(diversity),
      deployment: Math.round(deployment),
      techBreadth: Math.round(techBreadth),
      activity: Math.round(activity),
      openSource: Math.round(openSource)
    },
    label: scoreLabel
  };

  // 3. Text Summaries
  const executiveSummary = typeof raw.executiveSummary === 'string' && raw.executiveSummary.trim()
    ? raw.executiveSummary.trim()
    : 'Comprehensive developer portfolio evaluated across repository history, code quality, and engineering practices.';

  const hiringRecommendation = typeof raw.hiringRecommendation === 'string' && raw.hiringRecommendation.trim()
    ? raw.hiringRecommendation.trim()
    : 'Candidate demonstrates solid engineering capabilities across verified projects.';

  const recruiterSummary = typeof raw.recruiterSummary === 'string' && raw.recruiterSummary.trim()
    ? raw.recruiterSummary.trim()
    : executiveSummary;

  // 4. Strengths & Weaknesses
  const strengths = Array.isArray(raw.strengths)
    ? raw.strengths.map(s => String(s).trim()).filter(Boolean).slice(0, 4)
    : [];

  const weaknesses = Array.isArray(raw.weaknesses)
    ? raw.weaknesses.map(w => String(w).trim()).filter(Boolean).slice(0, 3)
    : [];

  // 5. Resume Evidence (Hybrid: deterministic fallback from evidence if not supplied)
  const deterministicEvidence = fallbackEvidence
    ? getDeterministicResumeEvidence(fallbackEvidence.skills, fallbackEvidence.technologySignals, fallbackEvidence.projects)
    : {};

  const rawResume = (raw.resumeEvidence && typeof raw.resumeEvidence === 'object' && !Array.isArray(raw.resumeEvidence))
    ? raw.resumeEvidence
    : {};

  const resumeEvidence = Object.keys(rawResume).length ? {} : deterministicEvidence;
  for (const [cat, data] of Object.entries(rawResume)) {
    if (data && typeof data === 'object') {
      const items = Array.isArray(data.evidence)
        ? data.evidence.map(e => String(e).trim()).filter(Boolean).slice(0, 3)
        : [];
      if (items.length) {
        resumeEvidence[cat] = {
          claim: typeof data.claim === 'string' ? data.claim : cat,
          evidence: items
        };
      }
    }
  }

  // 6. Top Projects (Deterministic facts prioritized for accuracy and zero truncation)
  const deterministicTop = fallbackEvidence?.projects
    ? getDeterministicTopProjects(fallbackEvidence.projects, 3)
    : [];

  let topProjects = deterministicTop;
  if (Array.isArray(raw.topProjects) && raw.topProjects.length >= 1) {
    topProjects = raw.topProjects.slice(0, 3).map(p => {
      const pBreakdown = p.breakdown || {};
      return {
        repoName: String(p.repoName || p.name || 'unnamed-repo').trim(),
        score: clamp(p.score, 0, 100, 75),
        breakdown: {
          stars: clamp(pBreakdown.stars, 0, 30, 10),
          readme: clamp(pBreakdown.readme, 0, 20, 10),
          description: clamp(pBreakdown.description, 0, 15, 8),
          activity: clamp(pBreakdown.activity, 0, 15, 8),
          size: clamp(pBreakdown.size, 0, 20, 10)
        },
        language: p.language ? String(p.language) : null,
        stars: clamp(p.stars, 0, 10000000, 0),
        repoUrl: p.repoUrl ? String(p.repoUrl) : null
      };
    });
  }

  // 7. Portfolio Showcase
  const deterministicShowcase = fallbackEvidence?.projects
    ? getDeterministicShowcase(fallbackEvidence.projects)
    : {};

  const rawShowcase = (raw.portfolioShowcase && typeof raw.portfolioShowcase === 'object' && !Array.isArray(raw.portfolioShowcase))
    ? raw.portfolioShowcase
    : {};

  const portfolioShowcase = {};
  for (const key of SHOWCASE_KEYS) {
    const rawItem = rawShowcase[key] || {};
    const detItem = deterministicShowcase[key] || {};

    portfolioShowcase[key] = {
      repoName: rawItem.repoName ? String(rawItem.repoName).trim() : (detItem.repoName || null),
      repoUrl: rawItem.repoUrl ? String(rawItem.repoUrl).trim() : (detItem.repoUrl || null),
      language: rawItem.language ? String(rawItem.language).trim() : (detItem.language || null),
      stars: clamp(rawItem.stars != null ? rawItem.stars : detItem.stars, 0, 10000000, 0),
      reason: rawItem.reason ? String(rawItem.reason).trim().slice(0, 200) : (detItem.reason || 'Key portfolio showcase project.'),
      score: clamp(rawItem.score != null ? rawItem.score : detItem.score, 0, 100, 80)
    };
  }

  // 8. Portfolio Gaps
  const rawGaps = Array.isArray(raw.portfolioGaps) ? raw.portfolioGaps : (Array.isArray(raw.gaps) ? raw.gaps : []);
  const portfolioGaps = rawGaps.slice(0, 4).map(g => {
    const severityStr = String(g.severity || 'medium').toLowerCase();
    const severity = VALID_SEVERITIES.has(severityStr) ? severityStr : 'medium';
    return {
      area: String(g.area || 'Engineering Practices').trim(),
      severity,
      advice: String(g.advice || 'Continue strengthening project architecture and automated testing.').trim()
    };
  });

  // 9. Recommendations
  const rawRecs = Array.isArray(raw.recommendations) ? raw.recommendations : [];
  const recommendations = rawRecs.slice(0, 4).map(r => {
    const prioStr = String(r.priority || 'medium').toLowerCase();
    const priority = VALID_PRIORITIES.has(prioStr) ? prioStr : 'medium';
    return {
      priority,
      recommendation: String(r.recommendation || r.advice || 'Enhance portfolio test coverage and deployment pipelines.').trim()
    };
  });

  // 10. Learning Roadmap
  const rawRoadmap = (raw.learningRoadmap && typeof raw.learningRoadmap === 'object' && !Array.isArray(raw.learningRoadmap))
    ? raw.learningRoadmap
    : {};
  const learningRoadmap = {};
  for (const m of ROADMAP_MONTHS) {
    const mData = rawRoadmap[m] || {};
    learningRoadmap[m] = {
      focus: typeof mData.focus === 'string' && mData.focus.trim() ? mData.focus.trim() : `Month ${m.replace('month', '')} Skill Enhancement`,
      tasks: Array.isArray(mData.tasks) ? mData.tasks.map(t => String(t).trim()).filter(Boolean).slice(0, 3) : []
    };
  }
  learningRoadmap.goal = typeof rawRoadmap.goal === 'string' && rawRoadmap.goal.trim()
    ? rawRoadmap.goal.trim()
    : 'Achieve advanced engineering fluency and production-readiness across the portfolio.';

  return {
    developerType,
    careerScore,
    executiveSummary,
    strengths,
    weaknesses,
    hiringRecommendation,
    recruiterSummary,
    resumeEvidence,
    topProjects,
    portfolioShowcase,
    portfolioGaps,
    recommendations,
    learningRoadmap
  };
}

export default {
  AnalysisValidationError,
  validateAndSanitizeAnalysis
};
