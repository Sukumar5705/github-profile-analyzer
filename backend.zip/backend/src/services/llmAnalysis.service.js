/**
 * llmAnalysis.service.js
 *
 * Stage: Single LLM Analysis Service
 * Coordinates prompt compilation, single LLM invocation against Gemini,
 * response validation, and automatic single retry on schema errors.
 */

import { buildMasterAnalysisPrompt } from '../prompts/masterAnalysis.prompt.js';
import { callGemini } from './gemini.service.js';
import { validateAndSanitizeAnalysis, AnalysisValidationError } from '../validation/analysisValidator.js';
import logger from '../utils/logger.js';

/**
 * Runs a single unified LLM analysis on developer evidence.
 * @param {object} evidence - DeveloperEvidence JSON from evidenceBuilder.js
 * @returns {Promise<object>} Validated analysis object
 */
export async function runAnalysis(evidence) {
  const username = evidence?.profile?.username || 'developer';
  logger.info(`[llmAnalysis.service] Starting single LLM analysis for ${username}`);

  const prompt = buildMasterAnalysisPrompt(evidence);

  try {
    const rawResult = await callGemini(prompt);
    const validated = validateAndSanitizeAnalysis(rawResult, evidence);
    logger.info(`[llmAnalysis.service] Successfully validated analysis for ${username}`);
    console.log(rawResult);
    console.log(validated);

    return validated;
  } catch (err) {
    if (err instanceof AnalysisValidationError) {
      logger.warn(`[llmAnalysis.service] Validation failed for ${username}: ${err.message}. Retrying with corrective instruction...`);

      const retryPrompt = `${prompt}\n\nIMPORTANT CORRECTION: Your previous output had schema validation errors:\n${(err.details || [err.message]).join('\n')}\nPlease ensure the response strictly conforms to the JSON structure provided.`;

      const retryRaw = await callGemini(retryPrompt);
      const validatedRetry = validateAndSanitizeAnalysis(retryRaw, evidence);
      logger.info(`[llmAnalysis.service] Successfully validated analysis on retry for ${username}`);
      return validatedRetry;
    }

    logger.error(`[llmAnalysis.service] Analysis execution failed for ${username}: ${err.message}`);
    throw err;
  }
}

export default {
  runAnalysis
};
