/**
 * Analysis Pipeline Service (Orchestrator)
 *
 * Target Architecture:
 * GitHub Data Fetch & Persist
 *   → Evidence Extraction (evidenceBuilder.js)
 *   → Single LLM Analysis (llmAnalysis.service.js)
 *   → JSON Validation (analysisValidator.js)
 *   → Persistence (analysis.repository.js)
 */

import { fetchAndPersist } from './githubData.service.js';
import { buildEvidence } from '../evidence/evidenceBuilder.js';
import { runAnalysis } from './llmAnalysis.service.js';
import { toAnalysisRecord } from '../mappers/llmAnalysisToAnalysisRecord.mapper.js';
import skillRepo from '../repositories/skill.repository.js';
import analysisRepo from '../repositories/analysis.repository.js';
import logger from '../utils/logger.js';

/**
 * Run the full evidence-based, single-LLM analysis pipeline for a GitHub username.
 * @param {string} username
 * @returns {Promise<object>} Full analysis result
 */
const analyzeProfile = async (username) => {
  logger.info(`[Pipeline] Starting Evidence + Single LLM analysis for: ${username}`);

  // Step 1: GitHub data → DB
  const { profileId, profileData, githubRepos } = await fetchAndPersist(username);

  // Step 2: Extract factual Developer Evidence
  const evidence = buildEvidence(profileData, githubRepos);

  // Step 3: Run single unified LLM analysis & validation
  const validatedAnalysis = await runAnalysis(evidence);

  // Step 4: Map to database record
  const analysisRecord = toAnalysisRecord(validatedAnalysis, evidence);

  // Step 5: Persist skills (with confidence)
  await skillRepo.replaceForProfile(profileId, evidence.skills);

  // Step 6: Persist analysis results + history
  await analysisRepo.save(profileId, analysisRecord);
  await analysisRepo.appendHistory(profileId, analysisRecord.careerScore.score);

  logger.info(
    `[Pipeline] Complete for ${username} — score: ${analysisRecord.careerScore.score}, type: ${analysisRecord.developerType.developerType}`
  );

  return {
    profile: { ...profileData, id: profileId },
    skills: evidence.skills,
    ...analysisRecord,
    executiveSummary: analysisRecord.executiveSummary,
    hiringRecommendation: analysisRecord.hiringRecommendation,
    recruiterSummary: analysisRecord.recruiterSummary,
    resumeEvidence: analysisRecord.resumeEvidence,
    portfolioShowcase: analysisRecord.portfolioShowcase,
    learningRoadmap: analysisRecord.learningRoadmap
  };
};

export { analyzeProfile };
export default { analyzeProfile };
