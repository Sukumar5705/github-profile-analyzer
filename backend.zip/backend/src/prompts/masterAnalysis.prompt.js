/**
 * masterAnalysis.prompt.js
 *
 * Ultra-compact, token-efficient prompt for Developer Portfolio Analysis.
 * Asks the LLM only for high-value reasoning & synthesis.
 * Concrete project facts, scores, and evidence are computed deterministically.
 */

/**
 * Builds the compact analysis prompt from developer evidence.
 * @param {object} evidence - DeveloperEvidence JSON from evidenceBuilder.js
 * @returns {string} Streamlined, token-efficient prompt
 */
export function buildMasterAnalysisPrompt(evidence) {
  const { profile, skills, technologySignals, projects } = evidence;

  // Send only top 8 repositories to minimize prompt footprint
  const topProjects = projects.slice(0, 8);

  const projectsText = topProjects.map(p => `
Repository: ${p.repoName}${p.isFork ? ' [FORK]' : ''}
Language: ${p.language || 'N/A'}
Stars: ${p.stars} | Forks: ${p.forks}
Description: ${p.description || 'None'}
Topics: ${p.topics?.length ? p.topics.join(', ') : 'None'}
Signals: ${p.detectedSignals?.length ? p.detectedSignals.join(', ') : 'None'}
README: ${p.hasReadme ? 'Yes' : 'No'} | Homepage: ${p.hasHomepage ? 'Yes' : 'No'}`).join('\n');

  const skillsText = skills.slice(0, 12).map(
    s => `${s.skill} (confidence: ${s.confidence}, repos: ${s.supportingRepoCount})`
  ).join(', ');

  return `
OUTPUT CONSTRAINTS:
- Return ONLY JSON matching the requested keys.
- Be concise. Use short factual sentences.
- Never hallucinate repositories, skills, or metrics not in the evidence.

EVALUATION RULES:
- Use ONLY supplied evidence.
- Evaluate impact relative to the developer's specific domain (e.g. Kernel / Systems, Backend, AI/ML, Frontend, DevOps).
- Do not penalize low-level or systems developers for lacking web frameworks.

EVIDENCE:

PROFILE:
- Username: ${profile.username}${profile.name ? ` (${profile.name})` : ''}
- Bio: ${profile.bio || 'None'}
- Followers: ${profile.followers} | Total Stars: ${profile.totalStars} | Total Forks: ${profile.totalForks}
- Public Repos: ${profile.publicRepos} (Original: ${profile.ownRepoCount}, Forks: ${profile.forkCount})
- Account Age: ${profile.accountAgeYears || 0} yrs | Top Language: ${profile.mostUsedLanguage || 'None'}
- Languages: ${JSON.stringify(profile.languageDistribution || {})}

SKILLS:
${skillsText || 'None extracted'}

TECHNICAL SIGNALS:
${JSON.stringify(technologySignals.aggregate || {})}

REPOSITORIES (Top ${topProjects.length}):
${projectsText}

TASK:
Generate a complete technical evaluation containing EXACTLY these JSON keys:
1. developerType: { developerType: string, confidence: number (0.0-1.0), reasons: array (max 3 items) }
2. careerScore: { score: number (0-100), breakdown: { documentation: number (max 20), diversity: number (max 20), deployment: number (max 20), techBreadth: number (max 15), activity: number (max 15), openSource: number (max 10) }, label: string }
3. executiveSummary: string (max 120 words) — holistic engineering evaluation.
4. strengths: array of strings (exactly 4 items) — citing actual repositories and tech.
5. weaknesses: array of strings (maximum 3 items) — genuine, actionable gaps.
6. hiringRecommendation: string (1-2 sentences) — clear hiring verdict and recommended level/domain.
7. recruiterSummary: string (max 80 words) — recruiter-facing candidate positioning.
8. portfolioGaps: array (maximum 4 items) [{ area: string, severity: "high"|"medium"|"low", advice: string }]
9. recommendations: array (maximum 4 items) [{ priority: "high"|"medium"|"low", recommendation: string }]
10. learningRoadmap: { month1: { focus, tasks: [3 items] }, month2: { focus, tasks: [3 items] }, month3: { focus, tasks: [3 items] }, goal: string }
`.trim();
}

export default {
  buildMasterAnalysisPrompt
};
