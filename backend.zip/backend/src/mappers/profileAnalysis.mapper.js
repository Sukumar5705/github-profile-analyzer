/**
 * Converts database values that may be JSON strings into JavaScript arrays.
 */
const toArray = (value) => {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
};

/**
 * Converts database values that may be JSON strings into JavaScript objects.
 */
const toObject = (value, fallback = {}) => {
  if (value && typeof value === 'object' && !Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) ? parsed : fallback;
    } catch {
      return fallback;
    }
  }
  return fallback;
};

/**
 * Safely converts database values into numbers.
 */
const toNumber = (value, fallback = 0) => {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
};

/**
 * Converts the database analysis representation into the domain structure expected by the frontend.
 */
const mapProfileAnalysisResponse = ({
  profile,
  skills,
  analysis,
  repositories,
}) => {
  if (!analysis) {
    return {
      profile,
      skills: skills ?? [],
      careerScore: null,
      developerType: null,
      recruiter: {
        strengths: [],
        concerns: [],
        highlights: [],
      },
      gaps: [],
      recommendations: [],
      topProjects: [],
      repositories: repositories ?? [],
      executiveSummary: null,
      hiringRecommendation: null,
      recruiterSummary: null,
      resumeEvidence: {},
      portfolioShowcase: null,
      learningRoadmap: null
    };
  }

  return {
    profile,
    skills: skills ?? [],
    careerScore: {
      score: toNumber(analysis.career_score),
      breakdown: {
        documentation: toNumber(analysis.score_documentation),
        diversity: toNumber(analysis.score_diversity),
        deployment: toNumber(analysis.score_deployment),
        techBreadth: toNumber(analysis.score_tech_breadth),
        activity: toNumber(analysis.score_activity),
        openSource: toNumber(analysis.score_open_source),
      },
    },
    developerType: {
      developerType: analysis.developer_type ?? 'Unknown',
      confidence: toNumber(analysis.developer_confidence),
      reasons: toArray(analysis.developer_reasons),
    },
    recruiter: {
      strengths: toArray(analysis.strengths),
      concerns: toArray(analysis.concerns),
      highlights: toArray(analysis.highlights),
    },
    gaps: toArray(analysis.gaps),
    recommendations: toArray(analysis.recommendations),
    topProjects: toArray(analysis.top_projects),
    repositories: repositories ?? [],

    // New LLM-powered persistent sections
    executiveSummary: analysis.executive_summary || null,
    hiringRecommendation: analysis.hiring_recommendation || null,
    recruiterSummary: analysis.recruiter_summary || null,
    resumeEvidence: toObject(analysis.resume_evidence, {}),
    portfolioShowcase: toObject(analysis.portfolio_showcase, null),
    learningRoadmap: toObject(analysis.learning_roadmap, null)
  };
};

export {
  mapProfileAnalysisResponse,
};
export default mapProfileAnalysisResponse;