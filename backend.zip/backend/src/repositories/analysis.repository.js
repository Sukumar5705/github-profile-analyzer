import db from '../config/db.js';

class AnalysisRepository {
  /**
   * Upsert the latest analysis result for a profile.
   * PostgreSQL ON CONFLICT replaces MySQL ON DUPLICATE KEY UPDATE.
   * @param {number} profileId
   * @param {object} data
   */
  async save(profileId, data) {
    await db.query(
      `INSERT INTO analysis_results
       (profile_id, career_score, score_documentation, score_diversity,
        score_deployment, score_tech_breadth, score_activity,
        score_open_source, total_stars, total_forks,
        most_used_language, top_projects,
        developer_type, developer_confidence, developer_reasons,
        strengths, concerns, gaps, recommendations,
        executive_summary, hiring_recommendation, recruiter_summary,
        resume_evidence, portfolio_showcase, learning_roadmap)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)
       ON CONFLICT (profile_id) DO UPDATE SET
         career_score          = EXCLUDED.career_score,
         score_documentation   = EXCLUDED.score_documentation,
         score_diversity       = EXCLUDED.score_diversity,
         score_deployment      = EXCLUDED.score_deployment,
         score_tech_breadth    = EXCLUDED.score_tech_breadth,
         score_activity        = EXCLUDED.score_activity,
         score_open_source     = EXCLUDED.score_open_source,
         total_stars           = EXCLUDED.total_stars,
         total_forks           = EXCLUDED.total_forks,
         most_used_language    = EXCLUDED.most_used_language,
         top_projects          = EXCLUDED.top_projects,
         developer_type        = EXCLUDED.developer_type,
         developer_confidence  = EXCLUDED.developer_confidence,
         developer_reasons     = EXCLUDED.developer_reasons,
         strengths             = EXCLUDED.strengths,
         concerns              = EXCLUDED.concerns,
         gaps                  = EXCLUDED.gaps,
         recommendations       = EXCLUDED.recommendations,
         executive_summary     = EXCLUDED.executive_summary,
         hiring_recommendation = EXCLUDED.hiring_recommendation,
         recruiter_summary     = EXCLUDED.recruiter_summary,
         resume_evidence       = EXCLUDED.resume_evidence,
         portfolio_showcase     = EXCLUDED.portfolio_showcase,
         learning_roadmap      = EXCLUDED.learning_roadmap,
         analyzed_at           = NOW()`,
      [
        profileId,
        data.careerScore?.score ?? 0,
        data.careerScore?.breakdown?.documentation ?? 0,
        data.careerScore?.breakdown?.diversity ?? 0,
        data.careerScore?.breakdown?.deployment ?? 0,
        data.careerScore?.breakdown?.techBreadth ?? 0,
        data.careerScore?.breakdown?.activity ?? 0,
        data.careerScore?.breakdown?.openSource ?? 0,
        data.totalStars ?? 0,
        data.totalForks ?? 0,
        data.mostUsedLanguage ?? 'Unknown',
        JSON.stringify(data.topProjects || []),
        data.developerType?.developerType || null,
        data.developerType?.confidence    || null,
        JSON.stringify(data.developerType?.reasons || []),
        JSON.stringify(data.recruiter?.strengths   || []),
        JSON.stringify(data.recruiter?.concerns    || []),
        JSON.stringify(data.gaps?.gaps             || []),
        JSON.stringify(data.recommendations        || []),
        data.executiveSummary || null,
        data.hiringRecommendation || null,
        data.recruiterSummary || null,
        JSON.stringify(data.resumeEvidence || {}),
        JSON.stringify(data.portfolioShowcase || {}),
        JSON.stringify(data.learningRoadmap || {})
      ]
    );
  }

  /**
   * Append a career score snapshot to the history table.
   * @param {number} profileId
   * @param {number} careerScore
   */
  async appendHistory(profileId, careerScore) {
    await db.query(
      'INSERT INTO analysis_history (profile_id, career_score) VALUES ($1, $2)',
      [profileId, careerScore]
    );
  }

  /**
   * Find the latest analysis result for a profile.
   * @param {number} profileId
   * @returns {Promise<object|null>}
   */
  async findByProfileId(profileId) {
    const { rows } = await db.query(
      'SELECT * FROM analysis_results WHERE profile_id = $1 LIMIT 1',
      [profileId]
    );
    return rows[0] || null;
  }

  /**
   * Return score history for a profile, oldest first.
   * @param {number} profileId
   * @param {number} limit
   * @returns {Promise<Array>}
   */
  async getHistory(profileId, limit = 20) {
    const { rows } = await db.query(
      `SELECT career_score, analyzed_at
       FROM analysis_history
       WHERE profile_id = $1
       ORDER BY analyzed_at ASC
       LIMIT $2`,
      [profileId, limit]
    );
    return rows;
  }
}

export default new AnalysisRepository();
