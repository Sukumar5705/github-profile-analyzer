import { Card, CardContent } from "@/components/ui/card"
import type { CareerScore, DeveloperType, HireDecision, Seniority } from "@/types/api"
import { CheckCircle2, Sparkles, Briefcase, Users, ShieldCheck } from "lucide-react"

interface HiringDecisionCardProps {
  careerScore: CareerScore
  developerType: DeveloperType
  hireDecision?: HireDecision
  seniority?: Seniority
  recommendedRole?: string
  recommendedTeam?: string
  confidence?: number
  confidenceReason?: string
}

interface VerdictConfig {
  label: string
  tagline: string
  interviewRec: string
  hiringLevel: string
  containerClass: string
  badgeClass: string
  scoreBarClass: string
}

function getVerdictConfig(decision?: string, score: number = 75, seniority?: string, role?: string): VerdictConfig {
  const level = seniority || (score >= 85 ? "Principal Engineer" : score >= 75 ? "Staff Engineer" : "Senior Engineer")
  const targetRole = role || `${level}`

  switch (decision) {
    case "Strong Hire":
      return {
        label: "Strong Hire",
        tagline: "Exceptional technical depth and verified portfolio. High priority hire.",
        interviewRec: "Fast-track to final on-site interview and executive alignment",
        hiringLevel: `${level} (Target: ${targetRole})`,
        containerClass: "border-emerald-500/40 bg-emerald-500/10",
        badgeClass: "bg-emerald-500 text-slate-950 font-bold",
        scoreBarClass: "bg-gradient-to-r from-emerald-500 to-teal-400"
      }
    case "Hire":
      return {
        label: "Hire",
        tagline: "Strong candidate with solid engineering foundation and verified repos.",
        interviewRec: "Proceed to standard technical interview loop",
        hiringLevel: `${level} (Target: ${targetRole})`,
        containerClass: "border-cyan-500/40 bg-cyan-500/10",
        badgeClass: "bg-cyan-500 text-slate-950 font-bold",
        scoreBarClass: "bg-gradient-to-r from-cyan-500 to-blue-400"
      }
    case "Leaning Hire":
      return {
        label: "Leaning Hire",
        tagline: "Positive signals. Verify specific systems depth and test automation.",
        interviewRec: "Focus screen on architecture and real-world system scaling",
        hiringLevel: `${level}`,
        containerClass: "border-blue-500/40 bg-blue-500/10",
        badgeClass: "bg-blue-500 text-white font-bold",
        scoreBarClass: "bg-gradient-to-r from-blue-500 to-indigo-400"
      }
    case "Leaning No Hire":
      return {
        label: "Leaning No Hire",
        tagline: "Portfolio lacks sufficient evidence or production readiness at target level.",
        interviewRec: "Conduct targeted technical phone screen before committing on-site",
        hiringLevel: "Needs Seniority Re-calibration",
        containerClass: "border-amber-500/40 bg-amber-500/10",
        badgeClass: "bg-amber-500 text-slate-950 font-bold",
        scoreBarClass: "bg-amber-500"
      }
    default:
      return {
        label: decision || "Evaluation Complete",
        tagline: "Comprehensive evaluation compiled from verified GitHub repositories.",
        interviewRec: "Review portfolio showcase and interview questions",
        hiringLevel: level,
        containerClass: "border-primary/40 bg-primary/10",
        badgeClass: "bg-primary text-primary-foreground font-bold",
        scoreBarClass: "bg-primary"
      }
  }
}

export function HiringDecisionCard({
  careerScore,
  developerType,
  hireDecision,
  seniority,
  recommendedRole,
  recommendedTeam,
  confidence,
  confidenceReason
}: HiringDecisionCardProps) {
  const score = careerScore.score
  const effectiveDecision = hireDecision || (score >= 85 ? "Strong Hire" : score >= 70 ? "Hire" : "Leaning Hire")
  const effectiveConfidence = confidence ?? Math.round((developerType.confidence ?? 0.9) * 100)
  const verdict = getVerdictConfig(effectiveDecision, score, seniority, recommendedRole)

  return (
    <Card className={`border-2 ${verdict.containerClass} backdrop-blur-sm shadow-xl transition-all`}>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row md:items-start gap-6">
          {/* Verdict badge */}
          <div className="flex-shrink-0 space-y-3">
            <span
              className={`inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-base font-bold shadow-md ${verdict.badgeClass}`}
              role="status"
            >
              <Sparkles className="h-4 w-4" />
              {verdict.label}
            </span>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <ShieldCheck className="h-4 w-4 text-cyan-400" />
              <span>AI Confidence: </span>
              <span className="font-semibold text-foreground">{effectiveConfidence}%</span>
            </div>
          </div>

          {/* Details */}
          <div className="flex-1 min-w-0 space-y-4">
            <p className="text-base font-semibold text-foreground">
              {verdict.tagline}
            </p>

            {/* Score bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span className="font-medium">AI Career Score</span>
                <span className="font-bold tabular-nums text-foreground">
                  {score} / 100
                </span>
              </div>
              <div
                className="h-2.5 w-full rounded-full bg-secondary/80 overflow-hidden"
                role="progressbar"
                aria-valuenow={score}
                aria-valuemin={0}
                aria-valuemax={100}
              >
                <div
                  className={`h-full rounded-full transition-all duration-700 ${verdict.scoreBarClass}`}
                  style={{ width: `${score}%` }}
                />
              </div>
            </div>

            {/* Facts Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="rounded-xl border border-border/50 bg-background/80 p-3 space-y-1">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                  <Briefcase className="h-3 w-3 text-primary" />
                  Target Role
                </p>
                <p className="text-xs font-bold text-foreground leading-snug">
                  {recommendedRole || verdict.hiringLevel}
                </p>
              </div>

              <div className="rounded-xl border border-border/50 bg-background/80 p-3 space-y-1">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                  <Users className="h-3 w-3 text-cyan-400" />
                  Target Team
                </p>
                <p className="text-xs font-bold text-foreground leading-snug">
                  {recommendedTeam || "Platform Engineering"}
                </p>
              </div>

              <div className="rounded-xl border border-border/50 bg-background/80 p-3 space-y-1">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                  Interview Next Step
                </p>
                <p className="text-xs font-medium text-foreground leading-snug">
                  {verdict.interviewRec}
                </p>
              </div>
            </div>

            {confidenceReason && (
              <p className="text-xs text-muted-foreground italic pt-1">
                "{confidenceReason}"
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}