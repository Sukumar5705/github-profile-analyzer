import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import type { InterviewPlanItem, InterviewQuestion } from "@/types/api"
import { HelpCircle, MessagesSquare, Lightbulb, CheckCircle2 } from "lucide-react"

interface InterviewPlanCardProps {
  interviewPlan?: InterviewPlanItem[]
  interviewQuestions?: InterviewQuestion[]
  interviewFocus?: string
  riskAreas?: string
}

export function InterviewPlanCard({
  interviewPlan,
  interviewQuestions,
  interviewFocus,
  riskAreas
}: InterviewPlanCardProps) {
  const hasPlan = interviewPlan && interviewPlan.length > 0
  const hasQuestions = interviewQuestions && interviewQuestions.length > 0

  if (!hasPlan && !hasQuestions && !interviewFocus && !riskAreas) return null

  return (
    <Card className="border-border/60 bg-card/80 backdrop-blur-sm shadow-lg hover:border-primary/40 transition-all">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-bold flex items-center gap-2 text-foreground">
          <MessagesSquare className="h-5 w-5 text-primary" />
          Technical Interview Plan & Question Bank
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Curated evaluation guide tailored for hiring managers and technical interviewers
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Interview Focus & Risk Focus */}
        {(interviewFocus || riskAreas) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {interviewFocus && (
              <div className="p-4 rounded-xl bg-primary/10 border border-primary/20 space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-primary uppercase tracking-wider">
                  <Lightbulb className="h-4 w-4" />
                  Primary Interview Focus
                </div>
                <p className="text-sm text-foreground leading-relaxed">{interviewFocus}</p>
              </div>
            )}

            {riskAreas && (
              <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-rose-400 uppercase tracking-wider">
                  <HelpCircle className="h-4 w-4" />
                  Risk Areas to Probe
                </div>
                <p className="text-sm text-foreground leading-relaxed">{riskAreas}</p>
              </div>
            )}
          </div>
        )}

        {/* Structured Interview Plan */}
        {hasPlan && (
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Recommended Interview Modules
            </h4>
            <div className="grid grid-cols-1 gap-3">
              {interviewPlan.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-secondary/30 border border-border/50 hover:bg-secondary/50 transition-colors space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                      <span className="text-sm font-bold text-foreground">{item.topic}</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    <strong className="text-foreground font-medium">Evaluation Rationale: </strong>
                    {item.reason}
                  </p>
                  {item.sampleQuestion && (
                    <div className="mt-2 p-3 rounded-lg bg-background/80 border border-border/40 text-xs text-primary font-mono leading-relaxed">
                      💬 <span className="font-semibold text-foreground">Sample Question: </span>
                      "{item.sampleQuestion}"
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Question Bank */}
        {hasQuestions && (
          <div className="space-y-3 pt-2">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Technical Question Bank
            </h4>
            <div className="space-y-3">
              {interviewQuestions.map((q, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-lg bg-secondary/20 border border-border/30 space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-primary">{q.category}</span>
                    <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-secondary text-muted-foreground border border-border/40">
                      {q.difficulty}
                    </span>
                  </div>
                  <p className="text-sm font-medium text-foreground">{q.question}</p>
                  {q.rationale && (
                    <p className="text-xs text-muted-foreground">{q.rationale}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
