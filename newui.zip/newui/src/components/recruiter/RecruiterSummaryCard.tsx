import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import type { Profile, DeveloperType } from "@/types/api"
import { FileText, Cpu, CheckCircle } from "lucide-react"

interface RecruiterSummaryCardProps {
  profile: Profile
  developerType: DeveloperType
  executiveSummary?: string
  technicalSummary?: string
  hiringRecommendation?: string
}

export function RecruiterSummaryCard({
  profile,
  developerType,
  executiveSummary,
  technicalSummary,
  hiringRecommendation
}: RecruiterSummaryCardProps) {
  const name = profile.name ?? `@${profile.username}`
  const effectiveExec = executiveSummary || `${name} is identified as a ${developerType.developerType} with strong technical depth across verified repositories.`

  return (
    <Card className="border-border/60 bg-card/80 backdrop-blur-sm shadow-lg hover:border-primary/40 transition-all">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold flex items-center gap-2 text-foreground">
            <FileText className="h-5 w-5 text-primary" />
            AI Executive & Technical Evaluation
          </CardTitle>
          <span className="text-xs text-muted-foreground">Hiring Intelligence Brief</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Executive Summary */}
        <div className="p-4 rounded-xl bg-secondary/30 border border-border/40 space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-primary uppercase tracking-wider">
            <FileText className="h-3.5 w-3.5" />
            Executive Brief
          </div>
          <p className="text-sm text-foreground leading-relaxed">
            {effectiveExec}
          </p>
        </div>

        {/* Technical Summary */}
        {technicalSummary && (
          <div className="p-4 rounded-xl bg-secondary/30 border border-border/40 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-wider">
              <Cpu className="h-3.5 w-3.5" />
              Technical Architecture & Depth
            </div>
            <p className="text-sm text-foreground leading-relaxed">
              {technicalSummary}
            </p>
          </div>
        )}

        {/* Hiring Recommendation */}
        {hiringRecommendation && (
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase tracking-wider">
              <CheckCircle className="h-3.5 w-3.5" />
              Hiring Committee Recommendation
            </div>
            <p className="text-sm text-foreground leading-relaxed font-medium">
              {hiringRecommendation}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}