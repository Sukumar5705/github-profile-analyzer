import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import type { CareerScore, ScoreBreakdownItem, HireDecision } from "@/types/api"
import { Award, CheckCircle, ShieldCheck } from "lucide-react"

interface CareerScoreCardProps {
  careerScore: CareerScore
  hireDecision?: HireDecision
  confidence?: number
  confidenceReason?: string
}

function scoreLabel(score: number): { label: string; color: string; badgeBg: string } {
  if (score >= 85) return { label: "Exceptional", color: "text-emerald-400", badgeBg: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" }
  if (score >= 70) return { label: "Strong", color: "text-blue-400", badgeBg: "bg-blue-500/15 text-blue-400 border-blue-500/30" }
  if (score >= 55) return { label: "Competent", color: "text-amber-400", badgeBg: "bg-amber-500/15 text-amber-400 border-amber-500/30" }
  return { label: "Developing", color: "text-rose-400", badgeBg: "bg-rose-500/15 text-rose-400 border-rose-500/30" }
}

function hireDecisionBadge(decision?: string): { text: string; badgeClass: string } {
  switch (decision) {
    case "Strong Hire":
      return { text: "Strong Hire", badgeClass: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" }
    case "Hire":
      return { text: "Hire", badgeClass: "bg-cyan-500/20 text-cyan-300 border-cyan-500/40" }
    case "Leaning Hire":
      return { text: "Leaning Hire", badgeClass: "bg-blue-500/20 text-blue-300 border-blue-500/40" }
    case "Leaning No Hire":
      return { text: "Leaning No Hire", badgeClass: "bg-amber-500/20 text-amber-300 border-amber-500/40" }
    default:
      return { text: decision || "Evaluation Complete", badgeClass: "bg-secondary text-foreground border-border" }
  }
}

export function CareerScoreCard({ careerScore, hireDecision, confidence, confidenceReason }: CareerScoreCardProps) {
  const { score, scoreBreakdown, confidence: scoreConf, confidenceReason: scoreConfReason } = careerScore
  const effectiveConfidence = confidence ?? scoreConf ?? 90
  const effectiveConfReason = confidenceReason || scoreConfReason || "Comprehensive evaluation based on verified public repositories."
  const { label, badgeBg } = scoreLabel(score)
  const decisionBadge = hireDecisionBadge(hireDecision)

  return (
    <Card className="border-border/60 bg-card/80 backdrop-blur-sm shadow-lg hover:border-primary/40 transition-all">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-0.5">
          <CardTitle className="text-xl font-bold flex items-center gap-2 text-foreground">
            <Award className="h-5 w-5 text-primary" />
            AI Career Score
          </CardTitle>
          <p className="text-xs text-muted-foreground">Staff Engineer & Committee Evaluation</p>
        </div>
        {hireDecision && (
          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${decisionBadge.badgeClass}`}>
            <CheckCircle className="h-3.5 w-3.5" />
            {decisionBadge.text}
          </span>
        )}
      </CardHeader>
      <CardContent className="space-y-5 pt-2">
        {/* Score ring / display */}
        <div className="flex items-baseline gap-3">
          <span className="text-6xl font-extrabold tabular-nums tracking-tight text-foreground">
            {score}
          </span>
          <span className="text-2xl font-light text-muted-foreground">
            / 100
          </span>
          <div className="ml-auto flex flex-col items-end">
            <span className={`px-2.5 py-0.5 rounded-md text-xs font-semibold border ${badgeBg}`}>
              {label}
            </span>
          </div>
        </div>

        {/* Overall progress bar */}
        <div
          className="h-2.5 w-full rounded-full bg-secondary/80 overflow-hidden"
          role="progressbar"
          aria-valuenow={score}
          aria-valuemin={0}
          aria-valuemax={100}
        >
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary via-cyan-400 to-emerald-400 transition-all duration-700"
            style={{ width: `${score}%` }}
          />
        </div>

        {/* AI Confidence Indicator (Phase 7) */}
        <div className="rounded-lg bg-secondary/40 border border-border/50 p-3 space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-medium text-foreground flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-cyan-400" />
              AI Evaluation Confidence
            </span>
            <span className="font-semibold text-cyan-400 tabular-nums">
              {effectiveConfidence}%
            </span>
          </div>
          <div className="h-1.5 w-full rounded-full bg-secondary overflow-hidden">
            <div
              className="h-full rounded-full bg-cyan-400 transition-all duration-500"
              style={{ width: `${effectiveConfidence}%` }}
            />
          </div>
          {effectiveConfReason && (
            <p className="text-[11px] text-muted-foreground leading-relaxed pt-0.5">
              {effectiveConfReason}
            </p>
          )}
        </div>

        {/* AI Score Breakdown with Rationale (Phase 8) */}
        {Array.isArray(scoreBreakdown) && scoreBreakdown.length > 0 && (
          <div className="space-y-3 pt-1">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              AI Score Dimensions
            </p>
            <div className="space-y-2.5">
              {scoreBreakdown.map((item: ScoreBreakdownItem, idx: number) => (
                <div key={idx} className="space-y-1 rounded-md bg-secondary/20 p-2 border border-border/30">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-medium text-foreground">
                      {item.category}
                    </span>
                    <span className="tabular-nums font-bold text-foreground">
                      {item.score}<span className="text-muted-foreground font-normal">/100</span>
                    </span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-secondary overflow-hidden">
                    <div
                      className="h-full rounded-full bg-primary/75 transition-all duration-500"
                      style={{ width: `${item.score}%` }}
                    />
                  </div>
                  {item.reason && (
                    <p className="text-[11px] text-muted-foreground leading-tight pt-0.5">
                      {item.reason}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
