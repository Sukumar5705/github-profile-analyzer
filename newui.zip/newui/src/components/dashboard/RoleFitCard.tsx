import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import type { RoleFit } from "@/types/api"
import { Target, CheckCircle2 } from "lucide-react"

interface RoleFitCardProps {
  roleFit?: RoleFit[]
}

function getFitColor(fit: number): { bar: string; badge: string } {
  if (fit >= 90) return { bar: "bg-emerald-400", badge: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" }
  if (fit >= 75) return { bar: "bg-cyan-400", badge: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20" }
  if (fit >= 60) return { bar: "bg-blue-400", badge: "text-blue-400 bg-blue-500/10 border-blue-500/20" }
  if (fit >= 40) return { bar: "bg-amber-400", badge: "text-amber-400 bg-amber-500/10 border-amber-500/20" }
  return { bar: "bg-rose-400", badge: "text-rose-400 bg-rose-500/10 border-rose-500/20" }
}

export function RoleFitCard({ roleFit }: RoleFitCardProps) {
  if (!roleFit || roleFit.length === 0) return null

  return (
    <Card className="border-border/60 bg-card/80 backdrop-blur-sm shadow-lg hover:border-primary/40 transition-all">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-bold flex items-center gap-2 text-foreground">
          <Target className="h-5 w-5 text-primary" />
          AI Role Fit Index
        </CardTitle>
        <p className="text-xs text-muted-foreground">Suitability match across engineering role specializations</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {roleFit.map((item, idx) => {
          const colors = getFitColor(item.fit)
          return (
            <div
              key={idx}
              className="p-3.5 rounded-xl bg-secondary/30 border border-border/40 hover:bg-secondary/50 transition-colors space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <span className="text-sm font-bold text-foreground">{item.role}</span>
                </div>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border tabular-nums ${colors.badge}`}>
                  {item.fit}% Fit
                </span>
              </div>

              {/* Progress bar */}
              <div className="h-2 w-full rounded-full bg-secondary overflow-hidden">
                <div
                  className={`h-full rounded-full ${colors.bar} transition-all duration-700`}
                  style={{ width: `${item.fit}%` }}
                />
              </div>

              {item.reason && (
                <p className="text-xs text-muted-foreground leading-relaxed pt-0.5">
                  {item.reason}
                </p>
              )}
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
