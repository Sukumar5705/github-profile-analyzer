import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import type { DeveloperType, Seniority } from "@/types/api"
import { Briefcase, Compass, Users, Sparkles } from "lucide-react"

interface DeveloperTypeCardProps {
  developerType: DeveloperType
  seniority?: Seniority
  recommendedRole?: string
  recommendedTeam?: string
  teamFit?: string[]
}

export function DeveloperTypeCard({
  developerType,
  seniority,
  recommendedRole,
  recommendedTeam,
  teamFit
}: DeveloperTypeCardProps) {
  const { developerType: type } = developerType
  const effectiveSeniority = seniority || "Senior Engineer"
  const effectiveRole = recommendedRole || `${effectiveSeniority} - ${type}`
  const effectiveTeam = recommendedTeam || "Platform Infrastructure"
  const effectiveTeams = teamFit && teamFit.length ? teamFit : developerType.reasons

  return (
    <Card className="border-border/60 bg-card/80 backdrop-blur-sm shadow-lg hover:border-primary/40 transition-all">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold flex items-center gap-2 text-foreground">
            <Compass className="h-5 w-5 text-primary" />
            Engineering Profile & Role Fit
          </CardTitle>
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-primary/15 text-primary border border-primary/30">
            <Sparkles className="h-3 w-3" />
            {effectiveSeniority}
          </span>
        </div>
        <p className="text-xs text-muted-foreground">Domain Specialization & Placement Target</p>
      </CardHeader>
      <CardContent className="space-y-5 pt-2">
        {/* Core Specialization */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-primary/10 via-secondary/40 to-secondary/20 border border-primary/20 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-primary uppercase tracking-wider">
              Primary Specialization
            </span>
          </div>
          <p className="text-2xl font-extrabold text-foreground tracking-tight">{type}</p>
        </div>

        {/* Recommended Role & Team Placement */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3 rounded-lg bg-secondary/30 border border-border/40 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Briefcase className="h-3.5 w-3.5 text-primary" />
              <span>Recommended Role</span>
            </div>
            <p className="text-sm font-semibold text-foreground leading-snug">{effectiveRole}</p>
          </div>

          <div className="p-3 rounded-lg bg-secondary/30 border border-border/40 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Users className="h-3.5 w-3.5 text-cyan-400" />
              <span>Target Team</span>
            </div>
            <p className="text-sm font-semibold text-foreground leading-snug">{effectiveTeam}</p>
          </div>
        </div>

        {/* Team Fit Tags (Phase 10) */}
        {effectiveTeams && effectiveTeams.length > 0 && (
          <div className="space-y-2 pt-1">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Users className="h-3.5 w-3.5" />
              Team Placement Matches
            </p>
            <div className="flex flex-wrap gap-2">
              {effectiveTeams.map((team) => (
                <span
                  key={team}
                  className="inline-flex items-center rounded-lg bg-secondary/70 border border-border/50 px-3 py-1 text-xs font-medium text-foreground hover:bg-primary/15 hover:border-primary/40 transition-colors"
                >
                  {team}
                </span>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
