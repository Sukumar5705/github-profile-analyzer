import { useState } from "react"
import { useParams } from "react-router-dom"
import { useProfile } from "@/hooks/useProfileData"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import {
  Compass,
  Milestone,
  CheckCircle2,
  Circle,
  TrendingUp,
  Target,
  Sparkles,
  Calendar,
  AlertCircle,
  Zap
} from "lucide-react"

export function RoadmapPage() {
  const { username } = useParams<{ username: string }>()
  const { data, isLoading, isError, error } = useProfile(username ?? "")
  const [completedTasks, setCompletedTasks] = useState<Record<string, boolean>>({})

  if (!username) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="text-base font-medium text-foreground">No candidate selected</p>
        <p className="mt-2 text-sm text-muted-foreground">Select a candidate to view their career growth roadmap.</p>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-8 space-y-6 animate-pulse" aria-busy="true">
        <div className="h-44 rounded-2xl bg-secondary/60 border border-border" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="h-80 rounded-2xl bg-secondary/40 border border-border" />
          <div className="h-80 rounded-2xl bg-secondary/40 border border-border" />
          <div className="h-80 rounded-2xl bg-secondary/40 border border-border" />
        </div>
      </div>
    )
  }

  if (isError || !data) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="text-base font-medium text-foreground">Unable to load roadmap</p>
        <p className="mt-2 text-sm text-muted-foreground">
          {error instanceof Error ? error.message : "Please analyze this profile first."}
        </p>
      </div>
    )
  }

  const {
    profile,
    developerType,
    seniority,
    candidateRoadmap,
    learningRoadmap,
    portfolioGaps,
    recommendations
  } = data

  const roadmap = candidateRoadmap || learningRoadmap
  const nextStep = roadmap?.nextCareerStep || `Staff ${developerType?.developerType || "Software Engineer"}`
  const skillsToExpand = roadmap?.skillsToExpand || ["Distributed Systems", "Cloud Infrastructure", "CI/CD Automation"]

  const timelineData = roadmap?.timeline || {
    month1: roadmap?.month1 || { focus: "Architecture & Modularity", tasks: ["Refactor monolithic modules into decoupled packages", "Implement comprehensive integration tests"] },
    month2: roadmap?.month2 || { focus: "Performance & Scalability", tasks: ["Profile memory and CPU bottlenecks", "Implement Redis caching and connection pooling"] },
    month3: roadmap?.month3 || { focus: "Production Readiness & Open Source", tasks: ["Set up automated GitHub Actions release pipelines", "Write comprehensive API docs and live demo sites"] },
    goal: roadmap?.goal || "Achieve staff-level engineering leadership and high-impact open source credibility."
  }

  const months = [
    { key: "month1", title: "Month 1: Foundation & Architecture", data: timelineData.month1 },
    { key: "month2", title: "Month 2: Scale & Optimization", data: timelineData.month2 },
    { key: "month3", title: "Month 3: Production & Community", data: timelineData.month3 }
  ]

  // Calculate total tasks and completion
  let allTaskKeys: string[] = []
  months.forEach((m) => {
    (m.data?.tasks || []).forEach((_, i) => {
      allTaskKeys.push(`${m.key}-${i}`)
    })
  })

  const completedCount = allTaskKeys.filter(k => completedTasks[k]).length
  const progressPct = allTaskKeys.length > 0 ? Math.round((completedCount / allTaskKeys.length) * 100) : 0

  const toggleTask = (key: string) => {
    setCompletedTasks(prev => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <main className="mx-auto max-w-5xl px-4 py-8 space-y-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-border/60 bg-gradient-to-br from-card via-card/95 to-secondary/30 p-6 sm:p-8 backdrop-blur-sm shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-primary/15 text-primary border border-primary/30">
                <Sparkles className="h-3.5 w-3.5" />
                Current: {seniority || "Senior Engineer"}
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-secondary text-muted-foreground border border-border/50">
                {developerType?.developerType || "Software Engineer"}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
              {profile.name || `@${profile.username}`} — Career Growth Roadmap
            </h1>
            <p className="text-sm text-muted-foreground">
              Strategic trajectory designed to elevate engineering impact and career seniority
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-primary/10 border border-primary/20 text-center sm:text-right shrink-0">
            <div className="text-xs font-bold text-primary uppercase tracking-wider flex items-center justify-center sm:justify-end gap-1.5 mb-1">
              <Target className="h-3.5 w-3.5" />
              Target Next Level
            </div>
            <p className="text-base font-extrabold text-foreground">{nextStep}</p>
          </div>
        </div>

        {/* High-Leverage Skills to Expand */}
        {skillsToExpand && skillsToExpand.length > 0 && (
          <div className="space-y-2 pt-2 border-t border-border/40">
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="h-3.5 w-3.5 text-amber-400" />
              High-Leverage Skills to Expand
            </p>
            <div className="flex flex-wrap gap-2">
              {skillsToExpand.map((skill, i) => (
                <span
                  key={i}
                  className="inline-flex items-center rounded-xl bg-secondary/80 border border-border/50 px-3.5 py-1.5 text-xs font-semibold text-foreground hover:border-primary/40 transition-colors"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Progress Bar */}
      <Card className="border-border/60 bg-card/80 backdrop-blur-sm shadow-md">
        <CardContent className="p-5">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-bold text-foreground flex items-center gap-1.5">
              <TrendingUp className="h-4 w-4 text-primary" />
              Roadmap Milestone Progress
            </span>
            <span className="font-extrabold text-primary tabular-nums">
              {completedCount} of {allTaskKeys.length} Tasks Completed ({progressPct}%)
            </span>
          </div>
          <div className="h-2.5 w-full rounded-full bg-secondary overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-primary to-emerald-400 transition-all duration-500"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </CardContent>
      </Card>

      {/* 3-Month Actionable Timeline */}
      <div className="space-y-4">
        <div>
          <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
            <Milestone className="h-5 w-5 text-primary" />
            3-Month Actionable Sprint Plan
          </h2>
          <p className="text-xs text-muted-foreground">
            Structured monthly objectives to build verified portfolio proof
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {months.map((month, mIdx) => {
            const mData = month.data
            if (!mData) return null

            return (
              <div
                key={month.key}
                className="rounded-2xl border border-border/60 bg-card/90 p-5 shadow-lg flex flex-col justify-between space-y-4 hover:border-primary/40 transition-all"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-primary/10 text-primary border border-primary/20">
                      <Calendar className="h-3 w-3" />
                      Month {mIdx + 1}
                    </span>
                  </div>

                  <h3 className="text-sm font-extrabold text-foreground leading-snug">
                    {mData.focus || month.title}
                  </h3>

                  <div className="space-y-2 pt-2">
                    {(mData.tasks || []).map((task, tIdx) => {
                      const taskKey = `${month.key}-${tIdx}`
                      const isDone = Boolean(completedTasks[taskKey])

                      return (
                        <button
                          key={tIdx}
                          type="button"
                          onClick={() => toggleTask(taskKey)}
                          className={`w-full flex items-start gap-2.5 p-3 rounded-xl border text-left transition-all ${
                            isDone
                              ? "bg-emerald-500/10 border-emerald-500/30 text-muted-foreground line-through"
                              : "bg-secondary/30 border-border/40 hover:bg-secondary/60 text-foreground"
                          }`}
                        >
                          {isDone ? (
                            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                          ) : (
                            <Circle className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                          )}
                          <span className="text-xs font-medium leading-relaxed">{task}</span>
                        </button>
                      )
                    })}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Strategic Growth Goal */}
      {timelineData.goal && (
        <Card className="border-primary/30 bg-primary/5 backdrop-blur-sm shadow-md">
          <CardContent className="p-6 flex items-start gap-4">
            <div className="p-3 rounded-2xl bg-primary/15 text-primary shrink-0">
              <Compass className="h-6 w-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-primary uppercase tracking-wider">
                Strategic Career Growth Goal
              </h3>
              <p className="text-sm text-foreground leading-relaxed font-medium">
                {timelineData.goal}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Reference: Gaps & Recommendations */}
      {((portfolioGaps && portfolioGaps.length > 0) || (recommendations && recommendations.length > 0)) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          {portfolioGaps && portfolioGaps.length > 0 && (
            <Card className="border-border/60 bg-card/80 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-bold flex items-center gap-2 text-foreground">
                  <AlertCircle className="h-4 w-4 text-amber-400" />
                  Identified Portfolio Gaps
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2.5">
                {portfolioGaps.map((gap, i) => (
                  <div key={i} className="p-3 rounded-xl bg-secondary/30 border border-border/40 space-y-1">
                    <span className="text-xs font-bold text-foreground">{gap.area}</span>
                    <p className="text-xs text-muted-foreground leading-relaxed">{gap.advice}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {recommendations && recommendations.length > 0 && (
            <Card className="border-border/60 bg-card/80 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-bold flex items-center gap-2 text-foreground">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  Key Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2.5">
                {recommendations.map((rec, i) => (
                  <div key={i} className="p-3 rounded-xl bg-secondary/30 border border-border/40 space-y-1">
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-secondary text-primary border border-border/50">
                      {rec.priority} Priority
                    </span>
                    <p className="text-xs text-foreground leading-relaxed">{rec.recommendation}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </main>
  )
}
