import { useState } from "react"
import { useParams } from "react-router-dom"
import { useProfile } from "@/hooks/useProfileData"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import {
  Copy,
  Check,
  ExternalLink,
  Star,
  Award,
  Sparkles,
  Layers,
  ShieldCheck,
  Code2,
  FolderGit2
} from "lucide-react"

export function ResumePage() {
  const { username } = useParams<{ username: string }>()
  const { data, isLoading, isError, error } = useProfile(username ?? "")
  const [copied, setCopied] = useState(false)

  if (!username) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="text-base font-medium text-foreground">No candidate selected</p>
        <p className="mt-2 text-sm text-muted-foreground">Select a candidate to view resume intelligence.</p>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-8 space-y-6 animate-pulse" aria-busy="true">
        <div className="h-44 rounded-2xl bg-secondary/60 border border-border" />
        <div className="h-72 rounded-2xl bg-secondary/40 border border-border" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="h-64 rounded-2xl bg-secondary/40 border border-border" />
          <div className="h-64 rounded-2xl bg-secondary/40 border border-border" />
        </div>
      </div>
    )
  }

  if (isError || !data) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="text-base font-medium text-foreground">Unable to load resume intelligence</p>
        <p className="mt-2 text-sm text-muted-foreground">
          {error instanceof Error ? error.message : "Please analyze this profile first."}
        </p>
      </div>
    )
  }

  const {
    profile,
    developerType,
    seniority,
    recommendedRole,
    resumeHighlights,
    resumeEvidence,
    portfolioShowcase,
    strengths
  } = data

  const highlights = (resumeHighlights && resumeHighlights.length > 0)
    ? resumeHighlights
    : (strengths && strengths.length > 0 ? strengths : [
        `Architected and maintained key open-source repositories using ${data.summary?.mostUsedLanguage || 'modern languages'}.`,
        `Demonstrated technical leadership across ${data.summary?.totalStars || 0} GitHub stars and ${data.summary?.totalForks || 0} community forks.`
      ])

  const copyHighlights = () => {
    const text = highlights.map(h => `• ${h}`).join("\n")
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const showcaseEntries = portfolioShowcase ? Object.entries(portfolioShowcase).filter(([_, p]) => p && p.repoName) : []

  return (
    <main className="mx-auto max-w-5xl px-4 py-8 space-y-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-border/60 bg-gradient-to-br from-card via-card/95 to-secondary/30 p-6 sm:p-8 backdrop-blur-sm shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-primary/15 text-primary border border-primary/30">
                <Sparkles className="h-3.5 w-3.5" />
                {seniority || "Senior Engineer"}
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-secondary text-muted-foreground border border-border/50">
                {developerType?.developerType || "Software Engineer"}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
              {profile.name || `@${profile.username}`} — Resume Intelligence
            </h1>
            <p className="text-sm text-muted-foreground max-w-2xl">
              Target Role: <strong className="text-foreground">{recommendedRole || `${seniority} - ${developerType?.developerType}`}</strong>
            </p>
          </div>

          <button
            onClick={copyHighlights}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm shadow-lg hover:bg-primary/90 transition-all active:scale-95 self-start sm:self-center shrink-0"
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? "Copied Bullet Points!" : "Copy Resume Highlights"}
          </button>
        </div>
      </div>

      {/* Section 1: AI Resume Highlights (Bullet points for resume) */}
      <Card className="border-border/60 bg-card/80 backdrop-blur-sm shadow-lg">
        <CardHeader className="pb-3">
          <CardTitle className="text-xl font-bold flex items-center gap-2 text-foreground">
            <Award className="h-5 w-5 text-primary" />
            Impact-Driven Resume Highlights
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            Citable, metrics-backed bullet points optimized for technical leadership resumes
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          {highlights.map((highlight, idx) => (
            <div
              key={idx}
              className="flex items-start gap-3 p-3.5 rounded-xl bg-secondary/30 border border-border/40 hover:bg-secondary/50 transition-colors"
            >
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary mt-0.5">
                {idx + 1}
              </span>
              <p className="text-sm text-foreground leading-relaxed font-medium">
                {highlight}
              </p>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Section 2: Portfolio Showcase Projects */}
      {showcaseEntries.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                <FolderGit2 className="h-5 w-5 text-primary" />
                Featured Portfolio Showcase
              </h2>
              <p className="text-xs text-muted-foreground">
                Flagship repositories highlighting distinct engineering dimensions
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {showcaseEntries.map(([categoryKey, project]) => {
              if (!project || !project.repoName) return null

              const categoryLabels: Record<string, { label: string; badge: string }> = {
                resumeProject: { label: "Resume Flagship", badge: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
                technicalProject: { label: "Technical Deep-Dive", badge: "bg-cyan-500/15 text-cyan-400 border-cyan-500/30" },
                recruiterProject: { label: "Recruiter Spotlight", badge: "bg-purple-500/15 text-purple-400 border-purple-500/30" },
                architectureProject: { label: "Systems Architecture", badge: "bg-amber-500/15 text-amber-400 border-amber-500/30" }
              }

              const catInfo = categoryLabels[categoryKey] || { label: "Showcase Project", badge: "bg-secondary text-foreground" }

              return (
                <div
                  key={categoryKey}
                  className="p-5 rounded-2xl bg-card border border-border/60 hover:border-primary/40 transition-all shadow-md flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${catInfo.badge}`}>
                        {catInfo.label}
                      </span>
                      {project.score > 0 && (
                        <span className="text-xs font-bold text-primary">
                          Score: {project.score}/100
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <h3 className="text-base font-bold text-foreground truncate">
                        {project.repoName}
                      </h3>
                      {project.repoUrl && (
                        <a
                          href={project.repoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-muted-foreground hover:text-primary transition-colors"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      )}
                    </div>

                    <p className="text-xs text-muted-foreground leading-relaxed line-clamp-3">
                      {project.reason}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-border/40 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1 font-medium">
                      <Code2 className="h-3.5 w-3.5 text-primary" />
                      {project.language || "Multi-language"}
                    </span>
                    <span className="flex items-center gap-1 font-bold text-foreground">
                      <Star className="h-3.5 w-3.5 text-amber-400 fill-amber-400" />
                      {(project.stars || 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Section 3: Verifiable Resume Evidence by Category */}
      {resumeEvidence && Object.keys(resumeEvidence).length > 0 && (
        <div className="space-y-4">
          <div>
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-emerald-400" />
              Verifiable Evidence by Domain
            </h2>
            <p className="text-xs text-muted-foreground">
              Direct mapping of claimed technical proficiencies to GitHub repository proof
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(resumeEvidence).map(([domain, dataObj]) => {
              if (!dataObj) return null
              return (
                <div
                  key={domain}
                  className="p-5 rounded-2xl bg-secondary/30 border border-border/50 space-y-3"
                >
                  <div className="flex items-center gap-2">
                    <Layers className="h-4 w-4 text-primary" />
                    <h3 className="text-sm font-bold text-foreground capitalize">
                      {domain.replace(/([A-Z])/g, " $1")}
                    </h3>
                  </div>

                  {dataObj.claim && (
                    <p className="text-xs font-semibold text-primary/90 bg-primary/10 px-3 py-1.5 rounded-lg border border-primary/20">
                      {dataObj.claim}
                    </p>
                  )}

                  {Array.isArray(dataObj.evidence) && dataObj.evidence.length > 0 && (
                    <ul className="space-y-1.5 text-xs text-muted-foreground">
                      {dataObj.evidence.map((item, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                          <span className="leading-snug">{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}
    </main>
  )
}
